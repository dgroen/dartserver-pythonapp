--
-- PostgreSQL database dump
--

\restrict VkxhJBo4LggYRrOKzMysvdw0aE4senUw10iO9MfvkRuZMldmR9UBImyOrnydePt

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: api_key; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_key (
    id integer NOT NULL,
    player_id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(10) NOT NULL,
    name character varying(255),
    is_active boolean,
    last_used_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.api_key OWNER TO postgres;

--
-- Name: api_key_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_key_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_key_id_seq OWNER TO postgres;

--
-- Name: api_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_key_id_seq OWNED BY public.api_key.id;


--
-- Name: apikey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.apikey (
    id integer NOT NULL,
    player_id integer NOT NULL,
    key_name character varying(100) NOT NULL,
    api_key character varying(255) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    last_used timestamp without time zone,
    expires_at timestamp without time zone
);


ALTER TABLE public.apikey OWNER TO postgres;

--
-- Name: apikey_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.apikey_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.apikey_id_seq OWNER TO postgres;

--
-- Name: apikey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.apikey_id_seq OWNED BY public.apikey.id;


--
-- Name: dartboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dartboard (
    id integer NOT NULL,
    player_id integer NOT NULL,
    dartboard_id character varying(100) NOT NULL,
    wpa_key character varying(255) NOT NULL,
    name character varying(255),
    is_connected boolean,
    last_connected_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.dartboard OWNER TO postgres;

--
-- Name: dartboard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dartboard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dartboard_id_seq OWNER TO postgres;

--
-- Name: dartboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dartboard_id_seq OWNED BY public.dartboard.id;


--
-- Name: gameresults; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gameresults (
    id integer NOT NULL,
    game_type_id integer NOT NULL,
    player_id integer NOT NULL,
    player_order integer NOT NULL,
    start_score integer,
    final_score integer,
    is_winner boolean,
    double_out_enabled boolean,
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    game_session_id character varying(100) NOT NULL
);


ALTER TABLE public.gameresults OWNER TO postgres;

--
-- Name: gameresults_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gameresults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gameresults_id_seq OWNER TO postgres;

--
-- Name: gameresults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gameresults_id_seq OWNED BY public.gameresults.id;


--
-- Name: gametype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gametype (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp without time zone
);


ALTER TABLE public.gametype OWNER TO postgres;

--
-- Name: gametype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gametype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gametype_id_seq OWNER TO postgres;

--
-- Name: gametype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gametype_id_seq OWNED BY public.gametype.id;


--
-- Name: hotspot_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hotspot_config (
    id integer NOT NULL,
    player_id integer NOT NULL,
    dartboard_id character varying(100) NOT NULL,
    wpa_key character varying(255) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.hotspot_config OWNER TO postgres;

--
-- Name: hotspot_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hotspot_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hotspot_config_id_seq OWNER TO postgres;

--
-- Name: hotspot_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hotspot_config_id_seq OWNED BY public.hotspot_config.id;


--
-- Name: player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone,
    username character varying(100),
    email character varying(255)
);


ALTER TABLE public.player OWNER TO postgres;

--
-- Name: player_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.player_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.player_id_seq OWNER TO postgres;

--
-- Name: player_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.player_id_seq OWNED BY public.player.id;


--
-- Name: scores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scores (
    id integer NOT NULL,
    game_result_id integer NOT NULL,
    player_id integer NOT NULL,
    throw_sequence integer NOT NULL,
    turn_number integer NOT NULL,
    throw_in_turn integer NOT NULL,
    base_score integer NOT NULL,
    multiplier character varying(20) NOT NULL,
    multiplier_value integer NOT NULL,
    actual_score integer NOT NULL,
    score_before integer NOT NULL,
    score_after integer NOT NULL,
    dartboard_sends_actual_score boolean NOT NULL,
    is_bust boolean,
    is_finish boolean,
    thrown_at timestamp without time zone
);


ALTER TABLE public.scores OWNER TO postgres;

--
-- Name: scores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scores_id_seq OWNER TO postgres;

--
-- Name: scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scores_id_seq OWNED BY public.scores.id;


--
-- Name: api_key id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_key ALTER COLUMN id SET DEFAULT nextval('public.api_key_id_seq'::regclass);


--
-- Name: apikey id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apikey ALTER COLUMN id SET DEFAULT nextval('public.apikey_id_seq'::regclass);


--
-- Name: dartboard id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dartboard ALTER COLUMN id SET DEFAULT nextval('public.dartboard_id_seq'::regclass);


--
-- Name: gameresults id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gameresults ALTER COLUMN id SET DEFAULT nextval('public.gameresults_id_seq'::regclass);


--
-- Name: gametype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gametype ALTER COLUMN id SET DEFAULT nextval('public.gametype_id_seq'::regclass);


--
-- Name: hotspot_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotspot_config ALTER COLUMN id SET DEFAULT nextval('public.hotspot_config_id_seq'::regclass);


--
-- Name: player id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player ALTER COLUMN id SET DEFAULT nextval('public.player_id_seq'::regclass);


--
-- Name: scores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scores ALTER COLUMN id SET DEFAULT nextval('public.scores_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
d55f29e75045
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_key (id, player_id, key_hash, key_prefix, name, is_active, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: apikey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.apikey (id, player_id, key_name, api_key, is_active, created_at, last_used, expires_at) FROM stdin;
\.


--
-- Data for Name: dartboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dartboard (id, player_id, dartboard_id, wpa_key, name, is_connected, last_connected_at, created_at) FROM stdin;
\.


--
-- Data for Name: gameresults; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gameresults (id, game_type_id, player_id, player_order, start_score, final_score, is_winner, double_out_enabled, started_at, finished_at, game_session_id) FROM stdin;
509	6	11	0	301	20	t	f	2025-10-08 19:07:23.053684	2025-10-08 19:11:53.51381	800e5f22-64da-4e87-bc41-2ae808a38cf2
510	6	11	0	301	19	t	t	2025-10-08 19:14:25.538636	2025-10-08 19:18:04.698828	06d90699-dad4-4356-a204-0d86e4d47992
511	6	12	0	301	301	f	f	2025-10-08 20:00:26.27451	\N	c0738542-dabc-403a-a84b-4f65b48b915d
512	6	13	1	301	301	f	f	2025-10-08 20:00:26.280591	\N	c0738542-dabc-403a-a84b-4f65b48b915d
513	9	11	0	\N	0	t	f	2025-10-08 20:00:44.494432	2025-10-08 20:06:09.458804	b1e7fb17-bfa7-433b-a5fc-61822f99cdd4
514	9	11	0	\N	0	f	f	2025-10-08 20:14:29.862082	\N	711b2253-7ff2-4222-b45c-97dcf8ebb4f8
515	6	11	0	301	201	f	f	2025-10-08 20:14:45.266311	\N	f6807d5d-f37c-4b41-bde8-6f987f336942
516	6	11	0	301	280	f	f	2025-10-08 20:15:44.813647	\N	bd698fad-2a25-446e-9795-343f3615cb1a
517	6	11	0	301	301	f	f	2025-10-08 20:30:20.843476	\N	34a7325f-8dcb-4b73-a2f1-bc56d604f296
518	6	11	0	301	301	f	t	2025-10-09 19:14:10.926416	\N	f05b7c03-911f-491a-a22d-07d8e5da4247
519	6	11	0	301	4	t	t	2025-10-09 19:42:45.900064	2025-10-09 19:49:08.9541	07905bea-c271-449d-8f93-b1c118564fd8
520	6	14	0	301	301	f	f	2025-10-09 21:19:00.465372	\N	67b73a1a-80d0-4dd5-93f6-4ffd7719bbf1
521	6	11	0	301	46	t	f	2025-10-10 18:10:02.655089	2025-10-10 18:11:43.024901	d712e623-4bc7-4f0c-83b9-6c94e091a4da
522	6	15	0	301	301	f	f	2025-10-13 22:05:02.975379	\N	c0a5ab1f-2717-4e6b-9e6e-c533580930ee
523	6	16	1	301	301	f	f	2025-10-13 22:05:02.98084	\N	c0a5ab1f-2717-4e6b-9e6e-c533580930ee
524	6	15	0	301	301	f	f	2025-10-13 22:09:37.115048	\N	a41daf8d-a1c7-4a8e-a1e7-d80915379940
525	6	16	1	301	301	f	f	2025-10-13 22:09:37.119622	\N	a41daf8d-a1c7-4a8e-a1e7-d80915379940
526	6	12	0	301	301	f	f	2025-10-13 22:55:53.02832	\N	1b69720e-76e6-491d-ae0b-b9dcf74ea23f
527	6	13	1	301	301	f	f	2025-10-13 22:55:53.035349	\N	1b69720e-76e6-491d-ae0b-b9dcf74ea23f
528	8	12	0	501	501	f	f	2025-10-13 22:57:31.416116	\N	4be77fb6-0510-4d52-a208-e22a92a18bb6
529	8	13	1	501	501	f	f	2025-10-13 22:57:31.419823	\N	4be77fb6-0510-4d52-a208-e22a92a18bb6
530	6	12	0	301	301	f	f	2025-10-13 23:28:23.046515	\N	8be12458-7158-4838-b889-ce3e3cc0771e
531	6	13	1	301	301	f	f	2025-10-13 23:28:23.051719	\N	8be12458-7158-4838-b889-ce3e3cc0771e
532	6	11	0	301	301	f	f	2025-10-14 16:28:41.043492	\N	4528a833-5a19-4cf9-99b7-67deaf4062af
533	6	14	1	301	301	f	f	2025-10-14 16:28:41.04861	\N	4528a833-5a19-4cf9-99b7-67deaf4062af
534	6	11	0	301	301	f	f	2025-10-15 23:05:33.38129	\N	2a14f8da-e7b6-42cd-a026-56e2e67c49e5
535	8	11	0	501	501	f	f	2025-10-16 06:39:04.129878	\N	5a00bf11-ec3d-49a7-87f8-bd15e1dc9d1a
536	8	17	1	501	501	f	f	2025-10-16 06:39:04.137259	\N	5a00bf11-ec3d-49a7-87f8-bd15e1dc9d1a
\.


--
-- Data for Name: gametype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gametype (id, name, description, created_at) FROM stdin;
6	301	301 darts game	2025-10-08 19:07:23.050216
7	401	401 darts game	2025-10-08 20:00:02.316242
8	501	501 darts game	2025-10-08 20:00:02.318568
9	cricket	Cricket darts game	2025-10-08 20:00:02.320282
\.


--
-- Data for Name: hotspot_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hotspot_config (id, player_id, dartboard_id, wpa_key, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player (id, name, created_at, username, email) FROM stdin;
11	Dennis	2025-10-08 19:07:23.052616	\N	\N
12	Player 1	2025-10-08 20:00:26.273195	\N	\N
13	Player 2	2025-10-08 20:00:26.27992	\N	\N
14	Olivia	2025-10-09 21:19:00.464102	\N	\N
15	Test Player 1	2025-10-13 22:05:02.955812	\N	\N
16	Test Player 2	2025-10-13 22:05:02.980144	\N	\N
17	Suvi	2025-10-16 06:39:04.136381	\N	\N
\.


--
-- Data for Name: scores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scores (id, game_result_id, player_id, throw_sequence, turn_number, throw_in_turn, base_score, multiplier, multiplier_value, actual_score, score_before, score_after, dartboard_sends_actual_score, is_bust, is_finish, thrown_at) FROM stdin;
213	509	11	1	1	1	20	SINGLE	1	20	301	281	t	f	f	2025-10-08 19:08:33.24414
214	509	11	2	1	2	20	SINGLE	1	20	281	261	t	f	f	2025-10-08 19:08:48.76746
215	509	11	3	1	3	20	SINGLE	1	20	261	241	t	f	f	2025-10-08 19:08:53.275526
216	509	11	4	2	1	1	SINGLE	1	1	241	240	t	f	f	2025-10-08 19:09:19.463327
217	509	11	5	2	2	20	SINGLE	1	20	240	220	t	f	f	2025-10-08 19:09:22.648593
218	509	11	6	2	3	20	SINGLE	1	20	220	200	t	f	f	2025-10-08 19:09:26.162424
219	509	11	7	3	1	12	SINGLE	1	12	200	188	t	f	f	2025-10-08 19:09:40.999833
220	509	11	8	3	2	20	SINGLE	1	20	188	168	t	f	f	2025-10-08 19:09:46.45729
221	509	11	9	3	3	7	TRIPLE	3	21	168	147	t	f	f	2025-10-08 19:09:50.599744
222	509	11	10	4	1	20	SINGLE	1	20	147	127	t	f	f	2025-10-08 19:10:06.867801
223	509	11	11	4	2	5	SINGLE	1	5	127	122	t	f	f	2025-10-08 19:10:10.630526
224	509	11	12	4	3	18	SINGLE	1	18	122	104	t	f	f	2025-10-08 19:10:14.148542
225	509	11	13	5	1	20	SINGLE	1	20	104	84	t	f	f	2025-10-08 19:10:42.801756
226	509	11	14	5	2	1	SINGLE	1	1	84	83	t	f	f	2025-10-08 19:10:46.893945
227	509	11	15	5	3	20	SINGLE	1	20	83	63	t	f	f	2025-10-08 19:10:50.641585
228	509	11	16	6	1	20	SINGLE	1	20	63	43	t	f	f	2025-10-08 19:11:07.832166
229	509	11	17	6	2	20	SINGLE	1	20	43	23	t	f	f	2025-10-08 19:11:21.340138
230	509	11	18	6	3	3	SINGLE	1	3	23	20	t	f	f	2025-10-08 19:11:26.175545
231	509	11	19	7	1	20	TRIPLE	3	60	20	20	t	t	f	2025-10-08 19:11:38.934132
232	509	11	20	7	1	20	SINGLE	1	20	20	0	t	f	t	2025-10-08 19:11:53.510913
233	510	11	1	1	1	12	SINGLE	1	12	301	289	t	f	f	2025-10-08 19:15:15.804503
234	510	11	2	1	2	20	SINGLE	1	20	289	269	t	f	f	2025-10-08 19:15:18.628034
235	510	11	3	1	3	19	SINGLE	1	19	269	250	t	f	f	2025-10-08 19:15:21.677326
236	510	11	4	2	1	12	SINGLE	1	12	250	238	t	f	f	2025-10-08 19:15:44.290841
237	510	11	5	2	2	20	SINGLE	1	20	238	218	t	f	f	2025-10-08 19:15:47.64998
238	510	11	6	2	3	20	SINGLE	1	20	218	198	t	f	f	2025-10-08 19:15:51.207362
239	510	11	7	3	1	20	SINGLE	1	20	198	178	t	f	f	2025-10-08 19:16:08.584732
240	510	11	8	3	2	7	SINGLE	1	7	178	171	t	f	f	2025-10-08 19:16:12.310676
241	510	11	9	3	3	18	TRIPLE	3	54	171	117	t	f	f	2025-10-08 19:16:16.231858
242	510	11	10	4	1	20	SINGLE	1	20	117	97	t	f	f	2025-10-08 19:16:30.583669
243	510	11	11	4	2	7	TRIPLE	3	21	97	76	t	f	f	2025-10-08 19:16:34.950625
244	510	11	12	4	3	1	SINGLE	1	1	76	75	t	f	f	2025-10-08 19:16:42.717319
245	510	11	13	5	1	25	BULL	1	25	75	50	t	f	f	2025-10-08 19:17:20.641556
246	510	11	14	5	2	12	SINGLE	1	12	50	38	t	f	f	2025-10-08 19:17:31.703496
247	510	11	15	5	3	19	SINGLE	1	19	38	19	t	f	f	2025-10-08 19:17:37.291593
248	510	11	16	6	1	3	SINGLE	1	3	19	16	t	f	f	2025-10-08 19:17:56.199434
249	510	11	17	6	2	8	DOUBLE	2	16	16	0	t	f	t	2025-10-08 19:18:04.695652
250	513	11	1	1	1	20	DOUBLE	2	40	0	0	t	f	f	2025-10-08 20:01:05.374529
251	513	11	2	1	2	12	SINGLE	1	12	0	0	t	f	f	2025-10-08 20:01:11.129806
252	513	11	3	1	3	20	SINGLE	1	20	0	0	t	f	f	2025-10-08 20:01:16.623128
253	513	11	4	2	1	1	SINGLE	1	1	0	0	t	f	f	2025-10-08 20:01:39.268408
254	513	11	5	2	2	4	SINGLE	1	4	0	0	t	f	f	2025-10-08 20:01:42.757037
255	513	11	6	2	3	18	SINGLE	1	18	0	0	t	f	f	2025-10-08 20:01:45.43398
256	513	11	7	3	1	18	TRIPLE	3	54	0	0	t	f	f	2025-10-08 20:01:59.368024
257	513	11	8	3	2	10	SINGLE	1	10	0	0	t	f	f	2025-10-08 20:02:04.145954
258	513	11	9	3	3	15	SINGLE	1	15	0	0	t	f	f	2025-10-08 20:02:11.546444
259	513	11	10	4	1	15	SINGLE	1	15	0	0	t	f	f	2025-10-08 20:02:24.304673
260	513	11	11	4	2	10	TRIPLE	3	30	0	0	t	f	f	2025-10-08 20:02:27.83461
261	513	11	12	4	3	15	SINGLE	1	15	0	0	t	f	f	2025-10-08 20:02:30.608251
262	513	11	13	5	1	3	SINGLE	1	3	0	0	t	f	f	2025-10-08 20:02:43.885086
263	513	11	14	5	2	17	SINGLE	1	17	0	0	t	f	f	2025-10-08 20:02:48.345019
264	513	11	15	5	3	2	SINGLE	1	2	0	0	t	f	f	2025-10-08 20:02:51.533122
265	513	11	16	6	1	3	SINGLE	1	3	0	0	t	f	f	2025-10-08 20:03:08.05829
266	513	11	17	6	2	3	SINGLE	1	3	0	0	t	f	f	2025-10-08 20:03:11.271545
267	513	11	18	6	1	3	SINGLE	1	3	0	0	t	f	f	2025-10-08 20:03:26.768977
268	513	11	19	6	2	3	DOUBLE	2	6	0	0	t	f	f	2025-10-08 20:03:30.076258
269	513	11	20	6	3	2	SINGLE	1	2	0	0	t	f	f	2025-10-08 20:03:32.5744
270	513	11	21	7	1	17	SINGLE	1	17	0	0	t	f	f	2025-10-08 20:03:45.630916
271	513	11	22	7	2	19	SINGLE	1	19	0	0	t	f	f	2025-10-08 20:03:49.837387
272	513	11	23	7	3	2	TRIPLE	3	6	0	0	t	f	f	2025-10-08 20:03:53.58047
273	513	11	24	8	1	17	SINGLE	1	17	0	0	t	f	f	2025-10-08 20:04:07.963921
274	513	11	25	8	2	19	SINGLE	1	19	0	0	t	f	f	2025-10-08 20:04:14.226732
275	513	11	26	8	3	7	SINGLE	1	7	0	0	t	f	f	2025-10-08 20:04:17.950496
276	513	11	27	9	1	19	SINGLE	1	19	0	0	t	f	f	2025-10-08 20:04:29.956254
277	513	11	28	9	2	16	SINGLE	1	16	0	0	t	f	f	2025-10-08 20:04:35.54956
278	513	11	29	9	3	11	SINGLE	1	11	0	0	t	f	f	2025-10-08 20:04:38.833294
279	513	11	30	10	1	16	SINGLE	1	16	0	0	t	f	f	2025-10-08 20:04:52.608353
280	513	11	31	10	2	7	SINGLE	1	7	0	0	t	f	f	2025-10-08 20:04:55.609874
281	513	11	32	10	3	7	SINGLE	1	7	0	0	t	f	f	2025-10-08 20:04:58.619455
282	513	11	33	11	1	16	SINGLE	1	16	0	0	t	f	f	2025-10-08 20:05:14.297222
283	513	11	34	11	2	14	SINGLE	1	14	0	0	t	f	f	2025-10-08 20:05:21.001827
284	513	11	35	11	3	17	SINGLE	1	17	0	0	t	f	f	2025-10-08 20:05:24.168601
285	513	11	36	12	1	18	SINGLE	1	18	0	0	t	f	f	2025-10-08 20:05:39.780169
286	513	11	37	12	2	3	SINGLE	1	3	0	0	t	f	f	2025-10-08 20:05:43.392747
287	513	11	38	12	3	18	SINGLE	1	18	0	0	t	f	f	2025-10-08 20:05:46.901734
288	513	11	39	13	1	25	BULL	1	25	0	0	t	f	f	2025-10-08 20:05:58.449221
289	513	11	40	13	2	25	BULL	1	25	0	0	t	f	f	2025-10-08 20:06:02.201523
290	513	11	41	13	3	25	BULL	1	25	0	0	t	f	t	2025-10-08 20:06:09.455276
291	515	11	1	1	1	20	TRIPLE	3	60	301	241	t	f	f	2025-10-08 20:15:20.24959
292	515	11	2	1	2	20	SINGLE	1	20	241	221	t	f	f	2025-10-08 20:15:25.831634
293	515	11	3	1	3	20	SINGLE	1	20	221	201	t	f	f	2025-10-08 20:15:29.918334
294	516	11	1	1	1	5	SINGLE	1	5	301	296	t	f	f	2025-10-08 20:16:19.648383
295	516	11	2	1	2	1	SINGLE	1	1	296	295	t	f	f	2025-10-08 20:16:22.743262
296	516	11	3	1	3	5	TRIPLE	3	15	295	280	t	f	f	2025-10-08 20:16:26.97614
297	519	11	1	1	1	1	SINGLE	1	1	301	300	t	f	f	2025-10-09 19:43:14.430315
298	519	11	2	1	2	1	SINGLE	1	1	300	299	t	f	f	2025-10-09 19:43:19.367425
299	519	11	3	1	3	20	SINGLE	1	20	299	279	t	f	f	2025-10-09 19:43:22.909358
300	519	11	4	2	1	20	DOUBLE	2	40	279	239	t	f	f	2025-10-09 19:43:44.708129
301	519	11	5	2	2	20	DOUBLE	2	40	239	199	t	f	f	2025-10-09 19:43:47.712979
302	519	11	6	2	3	5	SINGLE	1	5	199	194	t	f	f	2025-10-09 19:43:51.064707
303	519	11	7	3	1	5	TRIPLE	3	15	194	179	t	f	f	2025-10-09 19:44:05.885176
304	519	11	8	3	2	1	SINGLE	1	1	179	178	t	f	f	2025-10-09 19:44:09.635458
305	519	11	9	3	3	1	SINGLE	1	1	178	177	t	f	f	2025-10-09 19:44:12.966652
306	519	11	10	4	1	1	SINGLE	1	1	177	176	t	f	f	2025-10-09 19:45:00.38189
307	519	11	11	4	2	5	SINGLE	1	5	176	171	t	f	f	2025-10-09 19:45:04.086992
308	519	11	12	4	3	20	SINGLE	1	20	171	151	t	f	f	2025-10-09 19:45:07.381439
309	519	11	13	5	1	18	SINGLE	1	18	151	133	t	f	f	2025-10-09 19:45:25.616669
310	519	11	14	5	2	5	SINGLE	1	5	133	128	t	f	f	2025-10-09 19:45:29.834592
311	519	11	15	5	3	5	SINGLE	1	5	128	123	t	f	f	2025-10-09 19:45:33.614224
312	519	11	16	6	1	1	SINGLE	1	1	123	122	t	f	f	2025-10-09 19:45:52.551334
313	519	11	17	6	2	1	SINGLE	1	1	122	121	t	f	f	2025-10-09 19:45:56.915091
314	519	11	18	6	3	20	SINGLE	1	20	121	101	t	f	f	2025-10-09 19:46:00.56124
315	519	11	19	7	1	5	SINGLE	1	5	101	96	t	f	f	2025-10-09 19:46:13.614371
316	519	11	20	7	2	5	TRIPLE	3	15	96	81	t	f	f	2025-10-09 19:46:16.90965
317	519	11	21	7	3	15	SINGLE	1	15	81	66	t	f	f	2025-10-09 19:46:22.225856
318	519	11	22	8	1	5	SINGLE	1	5	66	61	t	f	f	2025-10-09 19:46:57.84367
319	519	11	23	8	2	20	SINGLE	1	20	61	41	t	f	f	2025-10-09 19:47:01.603914
320	519	11	24	8	3	1	TRIPLE	3	3	41	38	t	f	f	2025-10-09 19:47:06.968242
321	519	11	25	9	1	19	SINGLE	1	19	38	19	t	f	f	2025-10-09 19:47:20.045373
324	519	11	26	9	1	3	SINGLE	1	3	38	35	t	f	f	2025-10-09 19:47:44.56214
325	519	11	27	9	2	2	SINGLE	1	2	35	33	t	f	f	2025-10-09 19:47:51.699925
326	519	11	28	9	3	8	SINGLE	1	8	33	25	t	f	f	2025-10-09 19:47:55.167122
327	519	11	29	10	1	12	SINGLE	1	12	25	13	t	f	f	2025-10-09 19:48:07.501383
328	519	11	30	10	2	6	SINGLE	1	6	13	7	t	f	f	2025-10-09 19:48:10.809093
329	519	11	31	10	3	3	SINGLE	1	3	7	4	t	f	f	2025-10-09 19:48:14.184736
330	519	11	32	11	1	18	SINGLE	1	18	4	4	t	t	f	2025-10-09 19:48:28.386678
331	519	11	33	11	1	1	SINGLE	1	1	4	3	t	f	f	2025-10-09 19:48:41.37973
333	519	11	34	11	1	2	DOUBLE	2	4	4	0	t	f	t	2025-10-09 19:49:08.951406
334	520	14	1	1	1	20	SINGLE	1	20	301	281	t	f	f	2025-10-09 21:19:19.773784
337	521	11	1	1	1	25	DBLBULL	2	50	301	251	t	f	f	2025-10-10 18:10:34.952081
338	521	11	2	1	2	25	BULL	1	25	251	226	t	f	f	2025-10-10 18:10:55.048215
339	521	11	3	1	3	60	TRIPLE	3	180	226	46	t	f	f	2025-10-10 18:11:14.428541
340	521	11	4	2	1	20	DOUBLE	2	40	46	6	t	f	f	2025-10-10 18:11:33.063411
341	521	11	5	2	2	3	DOUBLE	2	6	6	0	t	f	t	2025-10-10 18:11:43.021423
342	522	15	1	1	1	20	TRIPLE	3	60	301	241	f	f	f	2025-10-13 22:05:02.985904
343	524	15	1	1	1	6	TRIPLE	3	20	301	283	t	f	f	2025-10-13 22:09:39.016875
344	533	14	1	1	1	20	SINGLE	1	20	301	281	t	f	f	2025-10-14 16:29:10.254866
345	533	14	2	1	2	180	SINGLE	1	180	281	101	t	f	f	2025-10-14 16:29:19.550108
\.


--
-- Name: api_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_key_id_seq', 1, false);


--
-- Name: apikey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.apikey_id_seq', 1, false);


--
-- Name: dartboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dartboard_id_seq', 1, false);


--
-- Name: gameresults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gameresults_id_seq', 536, true);


--
-- Name: gametype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gametype_id_seq', 9, true);


--
-- Name: hotspot_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hotspot_config_id_seq', 1, false);


--
-- Name: player_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.player_id_seq', 17, true);


--
-- Name: scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scores_id_seq', 345, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: apikey apikey_api_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apikey
    ADD CONSTRAINT apikey_api_key_key UNIQUE (api_key);


--
-- Name: apikey apikey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apikey
    ADD CONSTRAINT apikey_pkey PRIMARY KEY (id);


--
-- Name: dartboard dartboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dartboard
    ADD CONSTRAINT dartboard_pkey PRIMARY KEY (id);


--
-- Name: gameresults gameresults_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gameresults
    ADD CONSTRAINT gameresults_pkey PRIMARY KEY (id);


--
-- Name: gametype gametype_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gametype
    ADD CONSTRAINT gametype_name_key UNIQUE (name);


--
-- Name: gametype gametype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gametype
    ADD CONSTRAINT gametype_pkey PRIMARY KEY (id);


--
-- Name: hotspot_config hotspot_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotspot_config
    ADD CONSTRAINT hotspot_config_pkey PRIMARY KEY (id);


--
-- Name: player player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_pkey PRIMARY KEY (id);


--
-- Name: scores scores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT scores_pkey PRIMARY KEY (id);


--
-- Name: ix_api_key_key_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_api_key_key_hash ON public.api_key USING btree (key_hash);


--
-- Name: ix_dartboard_dartboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_dartboard_dartboard_id ON public.dartboard USING btree (dartboard_id);


--
-- Name: ix_player_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_email ON public.player USING btree (email);


--
-- Name: ix_player_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_player_username ON public.player USING btree (username);


--
-- Name: api_key api_key_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- Name: apikey apikey_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apikey
    ADD CONSTRAINT apikey_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- Name: dartboard dartboard_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dartboard
    ADD CONSTRAINT dartboard_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- Name: gameresults gameresults_game_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gameresults
    ADD CONSTRAINT gameresults_game_type_id_fkey FOREIGN KEY (game_type_id) REFERENCES public.gametype(id);


--
-- Name: gameresults gameresults_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gameresults
    ADD CONSTRAINT gameresults_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- Name: hotspot_config hotspot_config_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotspot_config
    ADD CONSTRAINT hotspot_config_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- Name: scores scores_game_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT scores_game_result_id_fkey FOREIGN KEY (game_result_id) REFERENCES public.gameresults(id);


--
-- Name: scores scores_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT scores_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- PostgreSQL database dump complete
--

\unrestrict VkxhJBo4LggYRrOKzMysvdw0aE4senUw10iO9MfvkRuZMldmR9UBImyOrnydePt

