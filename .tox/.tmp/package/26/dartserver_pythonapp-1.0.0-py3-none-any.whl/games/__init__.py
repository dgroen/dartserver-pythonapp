"""
Game implementations
"""
